SELECT * FROM retail_store.order_items;
-- 1. Retrieve customer names and emails for email marketing
SELECT name, email FROM customers;

-- 2. View complete product catalog with all available details
SELECT * FROM products;

-- 3. List all unique product categories
SELECT DISTINCT category FROM products;

-- 4. Show all products priced above ₹1,000
SELECT * FROM products WHERE price > 1000;

-- 5. Display products within a mid-range price bracket (₹2,000 to ₹5,000)
SELECT * FROM products WHERE price BETWEEN 2000 AND 5000;

-- 6. Fetch data for specific customer IDs
SELECT * FROM customers WHERE customer_id IN (1, 2, 5, 10);

-- 7. Identify customers whose names start with the letter 'A'
SELECT * FROM customers WHERE name LIKE 'A%';

-- 8. List electronics products priced under ₹3,000
SELECT * FROM products WHERE category = 'Electronics' AND price < 3000;

-- 9. Display product names and prices in descending order of price
SELECT name, price FROM products ORDER BY price DESC;

-- 10. Display product names and prices, sorted by price and then by name
SELECT name, price FROM products ORDER BY price DESC, name ASC;


-- Level 2: Filtering and Formatting
-- 1. Retrieve orders where customer information is missing
SELECT * FROM orders WHERE customer_id IS NULL;

-- 2. Display customer names and emails using column aliases
SELECT name AS `Customer Name`, email AS `Email Address` FROM customers;

-- 3. Calculate total value per item ordered by multiplying quantity and item price
SELECT order_item_id, order_id, product_id, quantity, item_price, (quantity * item_price) AS total_item_value FROM order_items;

-- 4. Combine customer name and phone number in a single column
SELECT customer_id, CONCAT(name, ' (', COALESCE(phone, 'No Phone'), ')') AS customer_summary FROM customers;

-- 5. Extract only the date part from order timestamps
SELECT order_id, DATE(order_date) AS order_date_only, status FROM orders;

-- 6. List products that do not have any stock left
SELECT * FROM products WHERE stock_quantity = 0;

-- Level 3: Aggregations


-- 1. Count the total number of orders placed
=

-- 2. Calculate the total revenue collected from all orders
SELECT ROUND(SUM(total_amount), 2) AS total_revenue FROM orders;

-- 3. Calculate the average order value
SELECT ROUND(AVG(total_amount), 2) AS average_order_value FROM orders;

-- 4. Count the number of customers who have placed at least one order
SELECT COUNT(DISTINCT customer_id) AS active_customers_count FROM orders;

-- 5. Find the number of orders placed by each customer
SELECT customer_id, COUNT(order_id) AS total_orders FROM orders GROUP BY customer_id;

-- 6. Find total sales amount made by each customer
SELECT customer_id, ROUND(SUM(total_amount), 2) AS total_sales_amount FROM orders GROUP BY customer_id;

-- 7. List the number of products sold per category
SELECT p.category, SUM(oi.quantity) AS total_products_sold FROM order_items oi JOIN products p ON oi.product_id = p.product_id GROUP BY p.category;

-- 8. Find the average item price per category
SELECT category, ROUND(AVG(price), 2) AS average_item_price FROM products GROUP BY category;

-- 9. Show number of orders placed per day
SELECT DATE(order_date) AS order_day, COUNT(order_id) AS orders_count FROM orders GROUP BY DATE(order_date) ORDER BY order_day;

-- 10. List total payments received per payment method
SELECT method, ROUND(SUM(amount_paid), 2) AS total_payments_received FROM payments GROUP BY method;


-- Level 4: Multi-Table Queries (JOINS)
-- 1. Retrieve order details along with the customer name (INNER JOIN)
SELECT o.order_id, c.name AS customer_name, o.order_date, o.status, o.total_amount FROM orders o INNER JOIN customers c ON o.customer_id = c.customer_id;

-- 2. Get list of products that have been sold (INNER JOIN with order_items)
SELECT DISTINCT p.product_id, p.name, p.category FROM products p INNER JOIN order_items oi ON p.product_id = oi.product_id;

-- 3. List all orders with their payment method (INNER JOIN)
SELECT o.order_id, o.total_amount, pm.method AS payment_method FROM orders o INNER JOIN payments pm ON o.order_id = pm.order_id;

-- 4. Get list of customers and their orders (LEFT JOIN)
SELECT c.customer_id, c.name, o.order_id, o.order_date, o.total_amount FROM customers c LEFT JOIN orders o ON c.customer_id = o.customer_id;

-- 5. List all products along with order item quantity (LEFT JOIN)
SELECT p.product_id, p.name, COALESCE(SUM(oi.quantity), 0) AS total_quantity_sold FROM products p LEFT JOIN order_items oi ON p.product_id = oi.product_id GROUP BY p.product_id, p.name;

-- 6. List all payments including those with no matching orders (RIGHT JOIN)
SELECT o.order_id, o.status, p.payment_id, p.amount_paid, p.method FROM orders o RIGHT JOIN payments p ON o.order_id = p.order_id;

-- 7. Combine data from three tables: customer, order, and payment
SELECT c.customer_id, c.name AS customer_name, o.order_id, o.order_date, pm.method, pm.amount_paid FROM customers c INNER JOIN orders o ON c.customer_id = o.customer_id INNER JOIN payments pm ON o.order_id = pm.order_id;


-- Level 5: Subqueries (Inner Queries)

-- 1. List all products priced above the average product price
SELECT * FROM products WHERE price > (SELECT AVG(price) FROM products);

-- 2. Find customers who have placed at least one order
SELECT customer_id, name, email FROM customers WHERE customer_id IN (SELECT DISTINCT customer_id FROM orders);

-- 3. Show orders whose total amount is above the average for that customer
SELECT o1.order_id, o1.customer_id, o1.total_amount FROM orders o1 WHERE o1.total_amount > (SELECT AVG(o2.total_amount) FROM orders o2 WHERE o2.customer_id = o1.customer_id);

-- 4. Display customers who haven't placed any orders
SELECT * FROM customers WHERE customer_id NOT IN (SELECT DISTINCT customer_id FROM orders WHERE customer_id IS NOT NULL);

-- 5. Show products that were never ordered
SELECT * FROM products WHERE product_id NOT IN (SELECT DISTINCT product_id FROM order_items);

-- 6. Show highest value order per customer
SELECT customer_id, MAX(total_amount) AS highest_order_amount FROM orders GROUP BY customer_id;

-- 7. Highest Order Per Customer (Including Names)
SELECT c.name, o.customer_id, o.order_id, o.total_amount AS highest_order_amount FROM orders o JOIN customers c ON o.customer_id = c.customer_id WHERE o.total_amount = (SELECT MAX(total_amount) FROM orders WHERE customer_id = o.customer_id);

-- Level 6: Set Operations
-- 1. List all customers who have either placed an order or written a product review (UNION)
SELECT customer_id FROM orders UNION SELECT customer_id FROM product_reviews;

-- 2. List all customers who have placed an order as well as reviewed a product (MySQL INTERSECT Alternative)
SELECT DISTINCT customer_id FROM orders WHERE customer_id IN (SELECT DISTINCT customer_id FROM product_reviews);